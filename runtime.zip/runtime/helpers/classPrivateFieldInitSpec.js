var checkPrivateRedeclaration = require("./checkPrivateRedeclaration.js");
function _classPrivateFieldInitSpec(e, t, a) {
  checkPrivateRedeclaration(e, t), t.set(e, a);
}
module.exports = _classPrivateFieldInitSpec, module.exports.__esModule = true, module.exports["default"] = module.exports;