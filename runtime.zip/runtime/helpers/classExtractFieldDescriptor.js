var classPrivateFieldGet2 = require("./classPrivateFieldGet2.js");
function _classExtractFieldDescriptor(e, t) {
  return classPrivateFieldGet2(t, e);
}
module.exports = _classExtractFieldDescriptor, module.exports.__esModule = true, module.exports["default"] = module.exports;